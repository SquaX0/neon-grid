# Неоновая сетка — Telegram Mini App

Структура
- public/index.html — игра (Telegram-версия, SDK подключается с telegram.org)
- netlify/functions/scores.mts — онлайн-таблица рекордов (проверяет подпись Telegram)
- botfather-texts.txt, assets/ — тексты и картинки для BotFather

Быстрый запуск без таблицы: перетащите папку public на https://app.netlify.com/drop
С таблицей рекордов: `npm i -g netlify-cli && npm install && netlify deploy --prod`,
затем в Netlify -> Site configuration -> Environment variables добавьте BOT_TOKEN (токен из BotFather),
перезапустите деплой. В public/index.html замените TG_LINK на ссылку вида https://t.me/ВАШ_БОТ/ВАШ_SHORT_NAME.

## Реклама с вознаграждением в Telegram
В игре есть место для рекламы: кнопка «Реклама» (+1 бонус) и «Продолжить» после проигрыша появляются, как только определена функция
`window.NG_REWARDED(done)`, которая показывает ролик и вызывает done(true) после просмотра до конца (done(false) — если закрыли или ошибка).
Пример для рекламной сети (Adsgram или любой другой, сверьтесь с их документацией, сниппет не проверен). Добавьте в public/index.html перед </head>:

    <script src="https://sad.adsgram.ai/js/sad.min.js"></script>
    <script>
      window.NG_REWARDED = done => {
        window.Adsgram.init({ blockId: 'ВАШ_BLOCK_ID' }).show().then(() => done(true)).catch(() => done(false));
      };
    </script>

## Окно /start с кнопкой «Играть» (бот отвечает фото, текстом и кнопкой)
Файлы: netlify/functions/telegram.mts (приём сообщений), telegram-setup.mts (разовая настройка),
public/start-banner.png (баннер), public/terms.html и privacy.html (шаблоны — проверьте и впишите контакты).

1. Установите Node.js (nodejs.org) и выполните в папке проекта:
       npm i -g netlify-cli
       npm install
       netlify login
       netlify link          # выберите ваш существующий сайт
2. Добавьте переменные (токен — из @BotFather, секрет придумайте сами: латиница, цифры, _ и -):
       netlify env:set BOT_TOKEN "123456:ABC..."
       netlify env:set WEBHOOK_SECRET "my_long_random_secret_2026"
       netlify env:set SUPPORT "@ваш_юзернейм"     # необязательно, попадёт в описание бота
3. Выложите проект целиком (вместе с функциями):
       netlify deploy --prod
4. Откройте в браузере один раз: https://ВАШ-САЙТ.netlify.app/api/telegram-setup?secret=my_long_random_secret_2026
   В ответе у всех пяти пунктов должно быть "ok": true.
5. Отправьте боту /start.
