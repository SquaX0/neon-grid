import type { Config } from "@netlify/functions";

// One-time setup: open  https://YOUR-SITE/api/telegram-setup?secret=WEBHOOK_SECRET  in a browser.
// Registers the webhook, the "Играть" menu button, the /start command and the bot texts.
export default async (req: Request) => {
  const url = new URL(req.url);
  const secret = Netlify.env.get("WEBHOOK_SECRET");
  const token = Netlify.env.get("BOT_TOKEN");
  if (!secret || !token || url.searchParams.get("secret") !== secret) return new Response("forbidden", { status: 403 });
  const site = (Netlify.env.get("SITE_URL") || url.origin).replace(/\/$/, "");
  const support = Netlify.env.get("SUPPORT"); // e.g. @your_username (optional)
  const api = (method: string, body: unknown) =>
    fetch(`https://api.telegram.org/bot${token}/${method}`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) }).then((r) => r.json());

  const description =
    "Неоновая сетка — головоломка с блоками прямо в Telegram.\n\nСтавь фигуры на поле 8×8, собирай линии и бей рекорды. Игра подстраивается под тебя.\n\n" +
    "🧩 Блоки, линии и серии\n🎯 Задания с историей\n💣 4 бонуса\n📅 3 новых задания каждый день\n🏆 Таблица рекордов\n\n" +
    (support ? `Поддержка: ${support}\n\n` : "") + "Бесплатно. Жми «Играть» 👇";
  const out = {
    webhook: await api("setWebhook", { url: `${site}/api/telegram`, secret_token: secret, allowed_updates: ["message"] }),
    menu: await api("setChatMenuButton", { menu_button: { type: "web_app", text: "Играть", web_app: { url: site } } }),
    commands: await api("setMyCommands", { commands: [{ command: "start", description: "Начать игру" }] }),
    short: await api("setMyShortDescription", { short_description: "Головоломка с блоками: ставь фигуры, выполняй задания и бей рекорды." }),
    description: await api("setMyDescription", { description }),
  };
  return Response.json(out);
};

export const config: Config = { path: "/api/telegram-setup", method: "GET" };
