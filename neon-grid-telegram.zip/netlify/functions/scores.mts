import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import { verifyInitData } from "./lib/verify.mjs";

type Row = { id: number; name: string; score: number };
const json = (o: unknown, status = 200) =>
  new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });

export default async (req: Request) => {
  const url = new URL(req.url);
  if (req.method === "GET" && url.searchParams.get("ping")) return json({ ok: true });

  const token = Netlify.env.get("BOT_TOKEN");
  const store = getStore("scores");
  const top: Row[] = (await store.get("top", { type: "json" })) || [];

  if (req.method === "GET") {
    const user = verifyInitData(url.searchParams.get("initData") || "", token || "");
    if (!user) return json({ error: "unauthorized" }, 401);
    const entries = top.slice(0, 10).map((r, i) => ({ rank: i + 1, score: r.score, player: { publicName: r.name } }));
    return json({ entries });
  }

  if (req.method === "POST") {
    const body = await req.json().catch(() => ({}));
    const user = verifyInitData(String(body.initData || ""), token || "");
    const score = Math.floor(Number(body.score));
    if (!user) return json({ error: "unauthorized" }, 401);
    if (!Number.isFinite(score) || score < 0 || score > 1_000_000) return json({ error: "bad score" }, 400);
    const name = String(user.first_name || user.username || "Player").slice(0, 20);
    const me = top.find((r) => r.id === user.id);
    if (me) { if (score > me.score) me.score = score; me.name = name; } else top.push({ id: user.id, name, score });
    top.sort((a, b) => b.score - a.score);
    await store.setJSON("top", top.slice(0, 100));
    return json({ ok: true });
  }
  return json({ error: "method not allowed" }, 405);
};

export const config: Config = { path: "/api/scores" };
