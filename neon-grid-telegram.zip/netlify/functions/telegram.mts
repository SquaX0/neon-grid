import type { Config } from "@netlify/functions";
import { buildStart } from "./lib/start.mjs";

// Telegram webhook: answers /start (and /help, /play) with the banner, text and a "Play" button.
export default async (req: Request) => {
  if (req.method !== "POST") return new Response("ok");
  const secret = Netlify.env.get("WEBHOOK_SECRET");
  const token = Netlify.env.get("BOT_TOKEN");
  if (!secret || !token) return new Response("not configured", { status: 500 });
  if (req.headers.get("x-telegram-bot-api-secret-token") !== secret) return new Response("forbidden", { status: 403 });

  const update = await req.json().catch(() => null);
  const m = update?.message;
  if (m?.text && /^\/(start|help|play)(@\w+)?(\s|$)/i.test(m.text)) {
    const site = (Netlify.env.get("SITE_URL") || new URL(req.url).origin).replace(/\/$/, "");
    const s = buildStart({ name: m.from?.first_name, lang: m.from?.language_code, site });
    const r = await fetch(`https://api.telegram.org/bot${token}/sendPhoto`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ chat_id: m.chat.id, photo: s.photo, caption: s.caption, parse_mode: "HTML", reply_markup: s.markup }),
    });
    if (!r.ok) console.error("sendPhoto failed", r.status, await r.text());
  }
  return new Response("ok");
};

export const config: Config = { path: "/api/telegram" };
